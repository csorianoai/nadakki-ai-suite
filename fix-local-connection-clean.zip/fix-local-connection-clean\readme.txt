﻿=== Fix Local Connection Clean ===
Contributors: nadakki
Tags: localhost, connection, fix
Version: 1.0.1

Versión corregida sin caracteres extraños.

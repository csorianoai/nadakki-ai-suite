﻿=== Fix Local Connection ===
Contributors: nadakki
Tags: localhost, connection, fix, curl, error 28
Requires at least: 5.8
Tested up to: 6.3
Stable tag: 1.0.0

Soluciona problemas de conexión local en WordPress.

== Description ==
Repara cURL error 28 para conexiones locales (localhost, 127.0.0.1, 192.168.*)

== Installation ==
1. Sube el ZIP a WordPress
2. Activa el plugin
3. Funciona automáticamente

== Changelog ==
= 1.0.0 =
* Lanzamiento inicial

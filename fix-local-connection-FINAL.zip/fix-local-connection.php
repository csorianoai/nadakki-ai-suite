﻿<?php
/**
 * Plugin Name: Fix Local Connection
 * Plugin URI: https://nadakki.com
 * Description: Repara conexiones locales en WordPress - Soluciona cURL error 28
 * Version: 1.0.0
 * Author: Nadakki AI
 * License: GPL v2 or later
 * Text Domain: fix-local-connection
 */

if (!defined('ABSPATH')) exit;

class FixLocalConnection {
    
    public function __construct() {
        add_filter('http_request_args', array($this, 'fix_local_requests'), 10, 2);
        add_filter('https_ssl_verify', '__return_false');
    }
    
    public function fix_local_requests($args, $url) {
        if (strpos($url, '192.168.1.110') !== false || 
            strpos($url, 'localhost') !== false || 
            strpos($url, '127.0.0.1') !== false) {
            
            $args['reject_unsafe_urls'] = false;
            $args['sslverify'] = false;
            $args['timeout'] = 15;
        }
        return $args;
    }
}

new FixLocalConnection();
